package numbers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
//import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
//import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

public class RationalTest {

  /**
   * Tests the default constructor which should create a Rational number equivalent to zero.
   */
	
	// TESTS FOR :: Rational()
    // Test default constructor initializes to 0/1
    @Test
    public void defaultConstructorInitializesToZero() {
        Rational defaultRational = new Rational();
        assertEquals(0, defaultRational.getNumerator(), "Default constructor should initialize numerator to 0");
        assertEquals(1, defaultRational.getDenominator(), "Default constructor should initialize denominator to 1");
    }

    // Test the string representation of the default constructed Rational
    @Test
    public void defaultConstructorStringRepresentation() {
        Rational defaultRational = new Rational();
        assertEquals("0", defaultRational.toString(), "String representation of default constructed Rational should be '0'");
    }

    // Test the equality of two default constructed Rationals
    @Test
    public void defaultConstructedRationalsAreEqual() {
        Rational rationalOne = new Rational();
        Rational rationalTwo = new Rational();
        assertTrue(rationalOne.equals(rationalTwo), "Two default constructed Rationals should be equal");
    }

    // Test the value-based methods (floatValue, doubleValue) of the default constructed Rational
    @Test
    public void defaultConstructorValueBasedMethods() {
        Rational defaultRational = new Rational();
        assertEquals(0.0, defaultRational.floatValue(), 0.0, "Float value of default constructed Rational should be 0.0");
        assertEquals(0.0, defaultRational.doubleValue(), 0.0, "Double value of default constructed Rational should be 0.0");
    }

    // Test the behavior of operations on a default constructed Rational
    @Test
    public void operationsOnDefaultConstructedRational() {
        Rational defaultRational = new Rational();
        Rational anotherRational = new Rational(1, 2);

        Rational added = defaultRational.plus(anotherRational);
        assertEquals(anotherRational, added, "Adding any Rational to a default constructed Rational should equal the other Rational");

        Rational subtracted = defaultRational.minus(anotherRational);
        assertTrue(subtracted.equals(new Rational(-1, 2)), "Subtracting any Rational from a default constructed Rational should be the negation of the other Rational");

        Rational multiplied = defaultRational.times(anotherRational);
        assertEquals(new Rational(0, 1), multiplied, "Multiplying any Rational with a default constructed Rational should result in 0");
        // Since dividing by zero is not allowed, no need to test division by a default constructed Rational
    }

    /**
   	* Tests the constructor with a single parameter for the numerator which should set the denominator to 1.
   	*/
    // TESTS FOR :: Rational(int numerator)
    // Test single-parameter constructor with a positive numerator
    @Test
    public void positiveNumeratorInitializesCorrectly() {
        Rational rational = new Rational(5);
        assertEquals(5, rational.getNumerator(), "Numerator should be 5 for Rational(5)");
        assertEquals(1, rational.getDenominator(), "Denominator should be 1 for Rational(5)");
    }

    // Test single-parameter constructor with a negative numerator
    @Test
    public void negativeNumeratorInitializesCorrectly() {
        Rational rational = new Rational(-5);
        assertEquals(-5, rational.getNumerator(), "Numerator should be -5 for Rational(-5)");
        assertEquals(1, rational.getDenominator(), "Denominator should be 1 for Rational(-5)");
    }

    // Test single-parameter constructor with zero
    @Test
    public void zeroNumeratorInitializesCorrectly() {
        Rational rational = new Rational(0);
        assertEquals(0, rational.getNumerator(), "Numerator should be 0 for Rational(0)");
        assertEquals(1, rational.getDenominator(), "Denominator should be 1 for Rational(0)");
    }

    // Test the string representation of Rational initialized with single-parameter constructor
    @Test
    public void stringRepresentationForSingleParameterConstructor() {
        Rational positiveRational = new Rational(5);
        assertEquals("5", positiveRational.toString(), "String representation should be '5' for Rational(5)");

        Rational negativeRational = new Rational(-5);
        assertEquals("-5", negativeRational.toString(), "String representation should be '-5' for Rational(-5)");

        Rational zeroRational = new Rational(0);
        assertEquals("0", zeroRational.toString(), "String representation should be '0' for Rational(0)");
    }


    // Test equality of Rationals initialized with single-parameter constructor
    @Test
    public void equalityForSingleParameterConstructor() {
        Rational rationalOne = new Rational(7);
        Rational rationalTwo = new Rational(7);
        assertTrue(rationalOne.equals(rationalTwo), "Two Rationals with the same numerator and implicit denominator of 1 should be equal");

        Rational rationalThree = new Rational(-7);
        assertFalse(rationalOne.equals(rationalThree), "Rationals with different numerators should not be equal");
    }

    // Test arithmetic operations on Rationals initialized with single-parameter constructor
    @Test
    public void operationsOnSingleParameterConstructedRational() {
        Rational rational = new Rational(5);
        Rational anotherRational = new Rational(2);

        Rational added = rational.plus(anotherRational);
        assertEquals(new Rational(7), added, "Result of adding 5 and 2 should be 7/1");

        Rational subtracted = rational.minus(anotherRational);
        assertEquals(new Rational(3), subtracted, "Result of subtracting 2 from 5 should be 3/1");

        Rational multiplied = rational.times(anotherRational);
        assertEquals(new Rational(10), multiplied, "Result of multiplying 5 by 2 should be 10/1");

        Rational divided = rational.dividesBy(anotherRational);
        assertEquals(new Rational(5, 2), divided, "Result of dividing 5 by 2 should be 5/2");
    }
  
  // TESTS FOR :: Rational(int a, int b)
  //Test for zero denominator
  @Test
  public void constructorThrowsExceptionForZeroDenominator() {
      assertThrows(IllegalArgumentException.class, () -> new Rational(1, 0), "Denominator can't be zero.");
  }

  // Test for negative denominator
  @Test
  public void constructorHandlesNegativeDenominator() {
      Rational value = new Rational(1, -2);
      assertThat("The numerator should be -1 when the denominator is negative", value.getNumerator(), is(-1));
      assertThat("The denominator should be positive even if input was negative", value.getDenominator(), is(2));
  }

  // Test for Integer.MIN_VALUE to trigger overflow exception
  @Test
  public void constructorThrowsExceptionForIntegerMinValue() {
      assertThrows(IllegalArgumentException.class, () -> new Rational(Integer.MIN_VALUE, 1), "Operation would cause integer overflow.");
      assertThrows(IllegalArgumentException.class, () -> new Rational(1, Integer.MIN_VALUE), "Operation would cause integer overflow.");
  }

  // Test for simplification correctness
  @Test
  public void constructorSimplifiesFractionCorrectly() {
      Rational value = new Rational(4, 2);
      assertThat("Numerator should be simplified correctly", value.getNumerator(), is(2));
      assertThat("Denominator should be simplified correctly", value.getDenominator(), is(1));
  }

  // Test to ensure the constructor doesn't change positive fractions
  @Test
  public void constructorMaintainsPositiveFraction() {
      Rational value = new Rational(3, 4);
      assertThat("The numerator should remain 3", value.getNumerator(), is(3));
      assertThat("The denominator should remain 4", value.getDenominator(), is(4));
  }

  // Test edge cases around the simplification boundary
  @Test
  public void constructorEdgeCaseSimplification() {
      Rational valueNearGCD = new Rational(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
      assertEquals(Integer.MAX_VALUE - 1, valueNearGCD.getNumerator(), "Numerator is (Integer.MAX_VALUE - 1) and remains unchanged after simplification");
      assertEquals(Integer.MAX_VALUE, valueNearGCD.getDenominator(), "Denominator is Integer.MAX_VALUE and remains unchanged after simplification");
  }


  // Test with both numerator and denominator being negative
  @Test
  public void constructorHandlesBothNegativeValues() {
      Rational value = new Rational(-2, -3);
      assertThat("Numerator should be positive when both inputs are negative", value.getNumerator(), is(2));
      assertThat("Denominator should be positive when both inputs are negative", value.getDenominator(), is(3));
  }

  // Break the code on purpose to ensure test catches it
  @Test
  public void rationalSimplificationCorrectness() {
      Rational simplifiedRational = new Rational(100, 50); // Should simplify to 2/1
      assertEquals(2, simplifiedRational.getNumerator(), "Numerator should be simplified correctly to 2");
      assertEquals(1, simplifiedRational.getDenominator(), "Denominator should be simplified correctly to 1");
  }

  
  // TESTS FOR (copy constructor) :: Rational(Rational original) 
  //Test copying a standard positive rational number
  @Test
  public void copyOfPositiveRational() {
      // Given that I have created a Rational value using arguments 2 and 3
      Rational original = new Rational(2, 3);
      Rational copy = new Rational(original);

      // Then the copy should have numerator 2
      assertEquals(2, copy.getNumerator(), "The numerator of the copy should be 2");
      // And the copy should have denominator 3
      assertEquals(3, copy.getDenominator(), "The denominator of the copy should be 3");

      // Ensure the original and the copy are not the same object in memory
      assertNotSame(original, copy, "The original and the copy should not be the same object");
  }

  // Test copying a rational number with a negative numerator
  @Test
  public void copyOfNegativeNumeratorRational() {
      Rational original = new Rational(-4, 5);
      Rational copy = new Rational(original);

      assertEquals(-4, copy.getNumerator(), "The numerator of the copy should be -4");
      assertEquals(5, copy.getDenominator(), "The denominator of the copy should be 5");
  }

  // Test copying a rational number with a negative denominator (should be normalized in Rational)
  @Test
  public void copyOfNegativeDenominatorRational() {
      Rational original = new Rational(4, -5);
      Rational copy = new Rational(original);

      assertEquals(-4, copy.getNumerator(), "The numerator of the copy should be -4 after normalization");
      assertEquals(5, copy.getDenominator(), "The denominator of the copy should be 5 after normalization");
  }

  // Test copying a rational number representing zero
  @Test
  public void copyOfZeroRational() {
      Rational original = new Rational(0, 5);
      Rational copy = new Rational(original);

      assertEquals(0, copy.getNumerator(), "The numerator of the copy should be 0");
      assertEquals(1, copy.getDenominator(), "The denominator of the copy should be 1 after simplification");
  }

  // Test copying a rational number representing one
  @Test
  public void copyOfOneRational() {
      Rational original = new Rational(5, 5);
      Rational copy = new Rational(original);

      assertEquals(1, copy.getNumerator(), "The numerator of the copy should be 1 after simplification");
      assertEquals(1, copy.getDenominator(), "The denominator of the copy should be 1 after simplification");
  }

  // Test copying a rational number with large values to ensure no overflow in copy
  @Test
  public void copyOfLargeRational() {
      Rational original = new Rational(Integer.MAX_VALUE, 1);
      Rational copy = new Rational(original);

      assertEquals(Integer.MAX_VALUE, copy.getNumerator(), "The numerator of the copy should be Integer.MAX_VALUE");
      assertEquals(1, copy.getDenominator(), "The denominator of the copy should be 1");
  }

  // Test ensuring modifications to the copy do not affect the original
  @Test
  public void modificationsToCopyDoNotAffectOriginal() {
      Rational original = new Rational(3, 4);
      Rational copy = new Rational(original);
      // Simulate modification by creating a new instance based on the copy with altered values (not directly modifying due to immutability of Rational class)
      Rational modifiedCopy = new Rational(copy.getNumerator() + 1, copy.getDenominator() + 1);

      assertEquals(3, original.getNumerator(), "Original numerator should remain unchanged");
      assertEquals(4, original.getDenominator(), "Original denominator should remain unchanged");
      assertEquals(4, modifiedCopy.getNumerator(), "Modified copy's numerator should be 4");
      assertEquals(5, modifiedCopy.getDenominator(), "Modified copy's denominator should be 5");
  }
  
  // TESTS FOR :: getNumerator
  //Test getting the numerator of a positive rational number
  @Test
  public void getNumeratorOfPositiveRational() {
      // Given that I have created a Rational value using arguments 3 and 4
      Rational value = new Rational(3, 4);
      // Then the value should have numerator 3
      assertThat("The numerator should be 3", value.getNumerator(), is(3));
  }

  // Test getting the numerator of a negative rational number
  @Test
  public void getNumeratorOfNegativeRational() {
      // Given that I have created a Rational value using arguments -3 and 4
      Rational value = new Rational(-3, 4);
      // Then the value should have numerator -3
      assertThat("The numerator should be -3", value.getNumerator(), is(-3));
  }

  // Test getting the numerator of a rational number where the denominator is negative
  @Test
  public void getNumeratorWithNegativeDenominator() {
      // Given that I have created a Rational value using arguments 3 and -4
      Rational value = new Rational(3, -4);
      // The value should have numerator -3 because the Rational class should normalize the negative sign to the numerator
      assertThat("The numerator should be -3 after normalization", value.getNumerator(), is(-3));
  }

  // Test getting the numerator for zero
  @Test
  public void getNumeratorOfZero() {
      // Given that I have created a Rational value using arguments 0 and any non-zero integer, say 1
      Rational value = new Rational(0, 1);
      // Then the value should have numerator 0
      assertThat("The numerator of zero should be 0", value.getNumerator(), is(0));
  }

  // Test getting the numerator of a rational number with the maximum integer value
  @Test
  public void getNumeratorOfMaxInt() {
      // Given that I have created a Rational value using arguments Integer.MAX_VALUE and 1
      Rational value = new Rational(Integer.MAX_VALUE, 1);
      // Then the value should have numerator Integer.MAX_VALUE
      assertThat("The numerator should be Integer.MAX_VALUE", value.getNumerator(), is(Integer.MAX_VALUE));
  }

  // Test getting the numerator of a rational number with the minimum integer value
  @Test
  public void getNumeratorOfMinInt() {
      try {
          // Attempt to create a Rational number with Integer.MIN_VALUE and 1
          new Rational(Integer.MIN_VALUE, 1);
          // If the constructor does not throw an exception, the test should fail
          fail("Expected IllegalArgumentException was not thrown.");
      } catch (IllegalArgumentException e) {
          // Assert that the expected exception is thrown
          assertEquals("Operation would cause integer overflow.", e.getMessage());
      }
  }

  // Test ensuring that the numerator is returned correctly even if the rational number is simplified
  @Test
  public void getNumeratorAfterSimplification() {
      // Given that I have created a Rational value using arguments 6 and 8, which simplifies to 3/4
      Rational value = new Rational(6, 8);
      // Then the simplified value should have numerator 3
      assertThat("The numerator should be 3 after simplification", value.getNumerator(), is(3));
  }
  
  // TESTS FOR :: getDenominator
  // Test getting the denominator of a standard positive rational number
  @Test
  public void getDenominatorOfPositiveRational() {
      // Given that I have created a Rational value using arguments 3 and 5
      Rational value = new Rational(3, 5);
      // Then the value should have denominator 5
      assertThat("The denominator should be 5", value.getDenominator(), is(5));
  }

  // Test getting the denominator when it is negative (Rational should normalize to keep denominator positive)
  @Test
  public void getDenominatorWithInitialNegativeDenominator() {
      // Given that I have created a Rational value using arguments 3 and -5
      Rational value = new Rational(3, -5);
      // Then the value should have denominator 5 after normalization
      assertThat("The denominator should be 5 after normalization", value.getDenominator(), is(5));
  }

  // Test getting the denominator when both numerator and denominator are negative
  @Test
  public void getDenominatorWithBothNegative() {
      // Given that I have created a Rational value using arguments -3 and -5
      Rational value = new Rational(-3, -5);
      // Then the value should have denominator 5 as negatives are normalized
      assertThat("The denominator should be 5 as negatives are normalized", value.getDenominator(), is(5));
  }

  // Test getting the denominator for a rational number simplified to 1
  @Test
  public void getDenominatorAfterSimplificationToOne() {
      // Given that I have created a Rational value using arguments 5 and 5
      Rational value = new Rational(5, 5);
      // Then the simplified value should have denominator 1
      assertThat("The denominator should be 1 after simplification", value.getDenominator(), is(1));
  }

  // Test getting the denominator for the largest possible fraction that does not cause overflow
  @Test
  public void getDenominatorOfMaxValue() {
      // Given that I have created a Rational value using arguments Integer.MAX_VALUE and Integer.MAX_VALUE
      Rational value = new Rational(Integer.MAX_VALUE, Integer.MAX_VALUE);
      // Then the value should have denominator 1 after simplification
      assertThat("The denominator should be 1 for equal numerator and denominator", value.getDenominator(), is(1));
  }

  // Test ensuring the method handles denominators that result in simplification correctly
  @Test
  public void getDenominatorWithSimplificationNeeded() {
      // Given that I have created a Rational value using arguments 6 and 8, which simplifies to 3/4
      Rational value = new Rational(6, 8);
      // Then the simplified value should have denominator 4
      assertThat("The denominator should be 4 after simplification", value.getDenominator(), is(4));
  }

  // Test getting the denominator for a rational number with minimal positive values, ensuring it doesn't simplify to zero
  @Test
  public void getDenominatorOfMinimalPositiveValue() {
      // Given that I have created a Rational value using arguments 1 and Integer.MAX_VALUE
      Rational value = new Rational(1, Integer.MAX_VALUE);
      // Then the value should have denominator Integer.MAX_VALUE
      assertThat("The denominator should remain Integer.MAX_VALUE", value.getDenominator(), is(Integer.MAX_VALUE));
  }
  
  // TESTS FOR :: gcd
  // Test GCD with positive integers
  @Test
  public void gcdWithPositiveIntegers() {
      // Given two positive integers
      int a = 60;
      int b = 48;
      // Then the GCD should be 12
      assertThat("The GCD of 60 and 48 should be 12", Rational.gcd(a, b), is(12));
  }

  // Test GCD where one number is zero
  @Test
  public void gcdWithZero() {
      // Given an integer and zero
      int a = 0;
      int b = 5;
      // Then the GCD should be the non-zero integer
      assertThat("The GCD of 0 and 5 should be 5", Rational.gcd(a, b), is(5));
  }

  // Test GCD with both numbers being zero
  @Test
  public void gcdWithBothZeros() {
      // Given both integers as zero
      int a = 0;
      int b = 0;
      // Then the GCD should also be zero
      assertThat("The GCD of 0 and 0 should be 0", Rational.gcd(a, b), is(0));
  }

  // Test GCD with negative integers
  @Test
  public void gcdWithNegativeIntegers() {
      // Given two negative integers
      int a = -60;
      int b = -48;
      // Expecting the GCD to be positive
      assertEquals(12, Rational.gcd(a, b), "The GCD of -60 and -48 should be 12");
  }


  // Test GCD with one negative and one positive integer
  @Test
  public void gcdWithMixedSignIntegers() {
      // Given one positive and one negative integer
      int a = 60;
      int b = -48;
      // The GCD should still be positive
      assertThat("The GCD of 60 and -48 should be 12", Rational.gcd(a, b), is(12));
  }

  // Test GCD at the edge of integer boundaries
  @Test
  public void gcdWithEdgeCases() {
      // Given the max integer value and a divisor of it
      int a = Integer.MAX_VALUE;
      int b = 1; // Max integer is prime, so any GCD with 1 will be 1
      assertThat("The GCD of Integer.MAX_VALUE and 1 should be 1", Rational.gcd(a, b), is(1));
  }

  // Test GCD with Integer.MIN_VALUE which is a special case due to overflow concerns
  @Test
  public void gcdWithIntegerMinValue() {
      // Given Integer.MIN_VALUE and another negative number
      int a = Integer.MIN_VALUE;
      int b = -1;
      // This is more to demonstrate handling, GCD calculation might not normally handle MIN_VALUE due to overflow risks
      assertThat("Handling of Integer.MIN_VALUE in GCD calculation", Rational.gcd(a, b), is(1));
  }

  // Test GCD with one argument being Integer.MIN_VALUE and the other a positive integer
  @Test
  public void gcdWithIntegerMinValueAndPositiveInteger() {
      // Given Integer.MIN_VALUE and a positive integer
      int a = Integer.MIN_VALUE;
      int b = 1;
      // This test highlights the necessity to handle MIN_VALUE carefully to avoid arithmetic overflow
      assertThat("GCD calculation with Integer.MIN_VALUE and a positive integer needs careful overflow management", Rational.gcd(a, b), is(1));
  }
  
  // TESTS FOR :: intValue
  // Test conversion to int with a simple positive fraction
  @Test
  public void simplePositiveFractionToInt() {
      Rational value = new Rational(3, 2);
      assertEquals(1, value.intValue(), "3/2 should truncate to 1 when converted to int");
  }

  // Test conversion to int with a simple negative fraction
  @Test
  public void simpleNegativeFractionToInt() {
      Rational value = new Rational(-3, 2);
      assertEquals(-1, value.intValue(), "-3/2 should truncate to -1 when converted to int");
  }

  // Test conversion to int with zero
  @Test
  public void zeroFractionToInt() {
      Rational value = new Rational(0, 1);
      assertEquals(0, value.intValue(), "0/1 should convert to 0");
  }

  // Test conversion to int with a positive fraction less than one
  @Test
  public void positiveFractionLessThanOneToInt() {
      Rational value = new Rational(1, 2);
      assertEquals(0, value.intValue(), "1/2 should truncate to 0 when converted to int");
  }

  // Test conversion to int with a negative fraction less than one (in absolute value)
  @Test
  public void negativeFractionLessThanOneToInt() {
      Rational value = new Rational(-1, 2);
      assertEquals(0, value.intValue(), "-1/2 should truncate to 0 when converted to int");
  }

  // Test conversion to int with a whole number
  @Test
  public void wholeNumberToInt() {
      Rational value = new Rational(5, 1);
      assertEquals(5, value.intValue(), "5/1 should convert to 5");
  }

  // Test conversion to int with a large positive fraction
  @Test
  public void largePositiveFractionToInt() {
      Rational value = new Rational(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
      assertEquals(0, value.intValue(), "Max int value fraction should truncate to 0");
  }

  // Test conversion to int with a large negative fraction
  @Test
  public void largeNegativeFractionToInt() {
      Rational value = new Rational(-(Integer.MAX_VALUE - 1), Integer.MAX_VALUE);
      assertEquals(0, value.intValue(), "Large negative fraction should truncate to 0");
  }

  // Test conversion to int where numerator is much larger than denominator
  @Test
  public void largeNumeratorToInt() {
      Rational value = new Rational(100, 3);
      assertEquals(33, value.intValue(), "100/3 should truncate to 33 when converted to int");
  }

  // Test conversion to int where numerator is a negative number much larger in magnitude than the denominator
  @Test
  public void largeNegativeNumeratorToInt() {
      Rational value = new Rational(-100, 3);
      assertEquals(-33, value.intValue(), "-100/3 should truncate to -33 when converted to int");
  }
  
  // TESTS FOR :: longValue
  // Test conversion to long with a simple positive fraction
  @Test
  public void positiveFractionToLong() {
      Rational value = new Rational(10, 3);
      assertEquals(3L, value.longValue(), "10/3 should truncate to 3 when converted to long");
  }

  // Test conversion to long with a simple negative fraction
  @Test
  public void negativeFractionToLong() {
      Rational value = new Rational(-10, 3);
      assertEquals(-3L, value.longValue(), "-10/3 should truncate to -3 when converted to long");
  }

  // Test conversion to long with zero
  @Test
  public void zeroToLong() {
      Rational value = new Rational(0, 5);
      assertEquals(0L, value.longValue(), "0 should convert to 0L");
  }

  // Test conversion to long with a positive fraction less than one
  @Test
  public void positiveFractionLessThanOneToLong() {
      Rational value = new Rational(1, 2);
      assertEquals(0L, value.longValue(), "1/2 should truncate to 0 when converted to long");
  }

  // Test conversion to long with a negative fraction less than one (in absolute value)
  @Test
  public void negativeFractionLessThanOneToLong() {
      Rational value = new Rational(-1, 2);
      assertEquals(0L, value.longValue(), "-1/2 should truncate to 0 when converted to long");
  }

  // Test conversion to long with a whole number
  @Test
  public void wholeNumberToLong() {
      Rational value = new Rational(42, 1);
      assertEquals(42L, value.longValue(), "42/1 should convert to 42L");
  }

  @Test
  public void largeNumeratorToIntRangeToLong() {
      Rational value = new Rational(Integer.MAX_VALUE, 2);
      assertEquals((long) Integer.MAX_VALUE / 2, value.longValue(), "Max int value divided by 2 should correctly convert to long");
  }

  @Test
  public void maxValueToIntRangeToLong() {
      Rational value = new Rational(Integer.MAX_VALUE - 1, 1);
      assertEquals(Integer.MAX_VALUE - 1, value.longValue(), "One less than max int should correctly convert to long");
  }
  
  @Test
  public void largeNegativeNumeratorToIntRangeToLong() {
      Rational value = new Rational(-Integer.MAX_VALUE / 2, 1);
      assertEquals((long) -Integer.MAX_VALUE / 2, value.longValue(), "Large negative int values should correctly convert to long");
  }
  
  @Test
  public void fractionRoundingTowardsZeroToLong() {
	    // Adjusted values to prevent overflow while still testing rounding behavior
	    Rational positiveFraction = new Rational(1, 2); // Represents 0.5
	    assertEquals(0L, positiveFraction.longValue(), "Fraction slightly more than 0 should round towards 0");
	    Rational negativeFraction = new Rational(-1, 2); // Represents -0.5
	    assertEquals(0L, negativeFraction.longValue(), "Negative fraction slightly less than 0 should round towards 0");
	}

  // TESTS FOR :: floatValue
  @Test
  public void wholeNumberToFloat() {
      // Given a Rational representing the whole number 5
      Rational rational = new Rational(5, 1);
      // When converted to float
      float result = rational.floatValue();
      // Then the result should be exactly 5.0f
      assertEquals(5.0f, result, "Whole number conversion to float should be exact");
  }

  @Test
  public void simpleFractionToFloat() {
      // Given a Rational representing the fraction 1/2
      Rational rational = new Rational(1, 2);
      // When converted to float
      float result = rational.floatValue();
      // Then the result should be 0.5f
      assertEquals(0.5f, result, "Simple fraction conversion to float should be accurate");
  }
  
  @Test
  public void negativeNumberToFloat() {
      // Given a Rational representing the negative number -3/4
      Rational rational = new Rational(-3, 4);
      // When converted to float
      float result = rational.floatValue();
      // Then the result should be -0.75f
      assertEquals(-0.75f, result, "Negative number conversion to float should be accurate");
  }

  @Test
  public void overflowToFloat() {
      // Given a Rational with numerator much larger than denominator, potentially causing overflow
      Rational rational = new Rational(Integer.MAX_VALUE, 2);
      // When converted to float
      float result = rational.floatValue();
      // Then the result should not be infinite
      assertFalse(Float.isInfinite(result), "Conversion should not result in an infinite float value");
  }

  @Test
  public void precisionLossToFloat() {
      // Given a Rational representing a fraction with known precision loss when converting to float
      Rational rational = new Rational(1, 3);
      // When converted to float
      float result = rational.floatValue();
      // Then the result should be close to the expected value within the precision of float
      assertEquals(1.0f / 3.0f, result, 0.0001f, "Conversion should approximate to 0.3333 with acceptable precision loss");
  }

  // TESTS FOR :: doubleValue
  //Test conversion to double with a standard positive rational number
  @Test
  public void standardPositiveRationalToDouble() {
      Rational rational = new Rational(2, 3);
      double expected = 2.0 / 3.0;
      assertEquals(expected, rational.doubleValue(), "2/3 should correctly convert to double");
  }

  // Test conversion to double with a negative rational number
  @Test
  public void negativeRationalToDouble() {
      Rational rational = new Rational(-2, 3);
      double expected = -2.0 / 3.0;
      assertEquals(expected, rational.doubleValue(), "-2/3 should correctly convert to double");
  }

  // Test conversion to double where the denominator is greater than the numerator
  @Test
  public void smallFractionToDouble() {
      Rational rational = new Rational(1, 4);
      double expected = 0.25;
      assertEquals(expected, rational.doubleValue(), "1/4 should correctly convert to double");
  }

  // Test conversion to double with very large numbers to check for precision
  @Test
  public void largeNumbersToDouble() {
      Rational rational = new Rational(Integer.MAX_VALUE, Integer.MAX_VALUE - 1);
      double expected = (double) Integer.MAX_VALUE / (Integer.MAX_VALUE - 1);
      assertEquals(expected, rational.doubleValue(), 0.000000001, "Large rational numbers should correctly convert to double with reasonable precision");
  }

  // Test conversion to double with zero numerator
  @Test
  public void zeroNumeratorToDouble() {
      Rational rational = new Rational(0, 5);
      assertEquals(0.0, rational.doubleValue(), "0/5 should correctly convert to 0.0");
  }

  // Test conversion to double for rational numbers close to zero
  @Test
  public void closeToZeroToDouble() {
      Rational positiveCloseToZero = new Rational(1, Integer.MAX_VALUE);
      Rational negativeCloseToZero = new Rational(-1, Integer.MAX_VALUE);
      assertTrue(positiveCloseToZero.doubleValue() > 0, "Tiny positive rational should convert to a positive double close to zero");
      assertTrue(negativeCloseToZero.doubleValue() < 0, "Tiny negative rational should convert to a negative double close to zero");
  }

  // Test conversion to double for the edge case of the smallest negative value
  @Test
  public void smallestNegativeValueToDouble() {
      Rational rational = new Rational(-1, Integer.MAX_VALUE);
      double expected = -1.0 / Integer.MAX_VALUE;
      assertEquals(expected, rational.doubleValue(), "The smallest negative value should correctly convert to double");
  }

  // Test ensuring accurate conversion of rational numbers representing one and negative one
  @Test
  public void oneAndNegativeOneToDouble() {
      Rational one = new Rational(1, 1);
      Rational negativeOne = new Rational(-1, 1);
      assertEquals(1.0, one.doubleValue(), "1/1 should correctly convert to 1.0");
      assertEquals(-1.0, negativeOne.doubleValue(), "-1/1 should correctly convert to -1.0");
  }

  // Test conversion to double for irrational approximations (e.g., approximation of pi)
  @Test
  public void approximationOfPiToDouble() {
      Rational piApprox = new Rational(22, 7);
      double expected = 22.0 / 7.0;
      assertEquals(expected, piApprox.doubleValue(), "22/7 should be a reasonable approximation of pi in double");
  }
  
  // TEST FOR :: compareTo
  // Test comparing two identical rational numbers
  @Test
  public void compareToIdenticalRationals() {
      Rational rational1 = new Rational(2, 3);
      Rational rational2 = new Rational(2, 3);
      assertEquals(0, rational1.compareTo(rational2), "Identical rationals should be considered equal");
  }

  // Test comparing rational number to itself
  @Test
  public void compareToItself() {
      Rational rational = new Rational(1, 2);
      assertEquals(0, rational.compareTo(rational), "Rational compared to itself should be equal");
  }

  // Test comparing rational number greater than another
  @Test
  public void compareToRationalGreater() {
      Rational greater = new Rational(3, 2);
      Rational lesser = new Rational(1, 2);
      assertTrue(greater.compareTo(lesser) > 0, "3/2 should be considered greater than 1/2");
  }

  // Test comparing rational number less than another
  @Test
  public void compareToRationalLesser() {
      Rational lesser = new Rational(1, 4);
      Rational greater = new Rational(1, 2);
      assertTrue(lesser.compareTo(greater) < 0, "1/4 should be considered less than 1/2");
  }

  // Test comparing rational number with a double
  @Test
  public void compareToWithDouble() {
      Rational rational = new Rational(1, 2); // 0.5
      Double doubleNumber = 0.75;
      assertTrue(rational.compareTo(doubleNumber) < 0, "Rational 1/2 should be less than 0.75");
  }

  // Test comparing rational number with a float
  @Test
  public void compareToWithFloat() {
      Rational rational = new Rational(3, 4); // 0.75
      Float floatNumber = 0.5f;
      assertTrue(rational.compareTo(floatNumber) > 0, "Rational 3/4 should be greater than 0.5f");
  }

  // Test comparing rational number with an Integer
  @Test
  public void compareToWithInteger() {
      Rational rational = new Rational(5, 1); // 5
      Integer integerNumber = 4;
      assertTrue(rational.compareTo(integerNumber) > 0, "Rational 5 should be greater than 4");
  }

  // Test comparing rational number with a Long
  @Test
  public void compareToWithLong() {
      Rational rational = new Rational(1, 10); // 0.1
      Long longNumber = 1L;
      assertTrue(rational.compareTo(longNumber) < 0, "Rational 1/10 should be less than 1");
  }

  // Test comparing negative rational number with a positive double
  @Test
  public void compareToNegativeWithPositiveDouble() {
      Rational negativeRational = new Rational(-1, 2); // -0.5
      Double positiveDouble = 0.5;
      assertTrue(negativeRational.compareTo(positiveDouble) < 0, "Negative rational -1/2 should be less than 0.5");
  }

  // Test comparison with null should throw an exception
  @Test
  public void compareToNull() {
      Rational rational = new Rational(1, 2);
      assertThrows(NullPointerException.class, () -> rational.compareTo(null), "Comparing to null should throw NullPointerException");
  }

  // Test comparing very close values for potential rounding issues
  @Test
  public void compareToVeryCloseValues() {
      Rational rational1 = new Rational(1, 3); // Approximately 0.333...
      Rational rational2 = new Rational(1, 3); // Also approximately 0.333...
      assertEquals(0, rational1.compareTo(rational2), "Very close values should be considered equal");
  }
  
  // TESTS FOR :: opposite
  // Test calculating the opposite of a positive rational number
  @Test
  public void oppositeOfPositiveRational() {
      Rational original = new Rational(2, 3);
      Rational result = original.opposite();
      assertEquals(-2, result.getNumerator(), "Opposite of a positive numerator should be negative");
      assertEquals(3, result.getDenominator(), "Denominator should remain unchanged");
  }

  // Test calculating the opposite of a negative rational number
  @Test
  public void oppositeOfNegativeRational() {
      Rational original = new Rational(-2, 3);
      Rational result = original.opposite();
      assertEquals(2, result.getNumerator(), "Opposite of a negative numerator should be positive");
      assertEquals(3, result.getDenominator(), "Denominator should remain unchanged");
  }

  // Test calculating the opposite of zero
  @Test
  public void oppositeOfZero() {
      Rational zero = new Rational(0, 1);
      Rational result = zero.opposite();
      assertEquals(0, result.getNumerator(), "Opposite of zero should be zero");
      assertEquals(1, result.getDenominator(), "Denominator should remain 1");
  }

  // Test calculating the opposite of a rational number with a large positive numerator
  @Test
  public void oppositeOfLargePositiveNumerator() {
      Rational largePositive = new Rational(Integer.MAX_VALUE, 2);
      Rational result = largePositive.opposite();
      assertEquals(-Integer.MAX_VALUE, result.getNumerator(), "Opposite of a large positive numerator should be a large negative numerator");
      assertEquals(2, result.getDenominator(), "Denominator should remain unchanged");
  }

  // Test calculating the opposite of a rational number with one as the denominator
  @Test
  public void oppositeWithOneAsDenominator() {
      Rational oneDenominator = new Rational(5, 1);
      Rational result = oneDenominator.opposite();
      assertEquals(-5, result.getNumerator(), "Numerator should be negated");
      assertEquals(1, result.getDenominator(), "Denominator should remain as 1");
  }

  // Test calculating the opposite of a rational number with one as the numerator
  @Test
  public void oppositeWithOneAsNumerator() {
      Rational oneNumerator = new Rational(1, 5);
      Rational result = oneNumerator.opposite();
      assertEquals(-1, result.getNumerator(), "Numerator should be negated to -1");
      assertEquals(5, result.getDenominator(), "Denominator should remain unchanged");
  }
  
  // TESTS FOR :: reciprocal
  // Test getting the reciprocal of a positive rational number
  @Test
  public void reciprocalOfPositiveRational() {
      Rational original = new Rational(2, 3);
      Rational reciprocal = original.reciprocal();
      assertEquals(3, reciprocal.getNumerator(), "The numerator should be the original denominator");
      assertEquals(2, reciprocal.getDenominator(), "The denominator should be the original numerator");
  }

  // Test getting the reciprocal of a negative rational number
  @Test
  public void reciprocalOfNegativeRational() {
      Rational original = new Rational(-2, 3);
      Rational reciprocal = original.reciprocal();
      assertEquals(-3, reciprocal.getNumerator(), "The numerator should be positive and match the original denominator");
      // Expecting a positive denominator as the Rational constructor should ensure the denominator is always positive
      assertEquals(2, reciprocal.getDenominator(), "The denominator should be positive and match the absolute value of the original numerator");
  }

  // Test that attempting to get the reciprocal of zero throws IllegalArgumentException
  @Test
  public void reciprocalOfZero() {
      Rational zero = new Rational(0, 1);
      assertThrows(IllegalArgumentException.class, zero::reciprocal, "Attempting to get the reciprocal of zero should throw an IllegalArgumentException");
  }

  // Test getting the reciprocal of one
  @Test
  public void reciprocalOfOne() {
      Rational one = new Rational(1, 1);
      Rational reciprocal = one.reciprocal();
      assertEquals(1, reciprocal.getNumerator(), "The numerator of the reciprocal of one should be one");
      assertEquals(1, reciprocal.getDenominator(), "The denominator of the reciprocal of one should be one");
  }

  // Test getting the reciprocal of a fraction less than one
  @Test
  public void reciprocalOfFractionLessThanOne() {
      Rational original = new Rational(1, 2);
      Rational reciprocal = original.reciprocal();
      assertEquals(2, reciprocal.getNumerator(), "The numerator should be the original denominator");
      assertEquals(1, reciprocal.getDenominator(), "The denominator should be the original numerator");
  }

  // Test getting the reciprocal of a large rational number
  @Test
  public void reciprocalOfLargeRational() {
      Rational large = new Rational(Integer.MAX_VALUE, 2);
      Rational reciprocal = large.reciprocal();
      assertEquals(2, reciprocal.getNumerator(), "The numerator should be 2");
      assertEquals(Integer.MAX_VALUE, reciprocal.getDenominator(), "The denominator should be Integer.MAX_VALUE");
  }

  // Test getting the reciprocal of a rational number with a large denominator
  @Test
  public void reciprocalOfLargeDenominatorRational() {
      Rational largeDenominator = new Rational(1, Integer.MAX_VALUE);
      Rational reciprocal = largeDenominator.reciprocal();
      assertEquals(Integer.MAX_VALUE, reciprocal.getNumerator(), "The numerator should be Integer.MAX_VALUE");
      assertEquals(1, reciprocal.getDenominator(), "The denominator should be 1");
  }

  // Test getting the reciprocal of a rational number with both large numerator and denominator
  @Test
  public void reciprocalOfLargeNumeratorAndDenominatorRational() {
      Rational largeValues = new Rational(Integer.MAX_VALUE, Integer.MAX_VALUE - 1);
      Rational reciprocal = largeValues.reciprocal();
      assertEquals(Integer.MAX_VALUE - 1, reciprocal.getNumerator(), "The numerator should be Integer.MAX_VALUE - 1");
      assertEquals(Integer.MAX_VALUE, reciprocal.getDenominator(), "The denominator should be Integer.MAX_VALUE");
  }
  
  // TESTS FOR :: times
  // Test multiplying two positive rational numbers
  @Test
  public void multiplyPositiveRationals() {
      Rational r1 = new Rational(2, 3);
      Rational r2 = new Rational(4, 5);
      Rational result = r1.times(r2);
      assertEquals(8, result.getNumerator(), "Numerator should be the product of the numerators");
      assertEquals(15, result.getDenominator(), "Denominator should be the product of the denominators");
  }

  // Test multiplying a positive and a negative rational number
  @Test
  public void multiplyPositiveAndNegativeRationals() {
      Rational r1 = new Rational(2, 3);
      Rational r2 = new Rational(-4, 5);
      Rational result = r1.times(r2);
      assertEquals(-8, result.getNumerator(), "Numerator should be the product of the numerators with a negative sign");
      assertEquals(15, result.getDenominator(), "Denominator should remain positive");
  }

  // Test multiplying two negative rational numbers
  @Test
  public void multiplyNegativeRationals() {
      Rational r1 = new Rational(-2, 3);
      Rational r2 = new Rational(-4, 5);
      Rational result = r1.times(r2);
      assertEquals(8, result.getNumerator(), "Numerator should be positive as a product of two negatives");
      assertEquals(15, result.getDenominator(), "Denominator should remain positive");
  }

  // Test for overflow in the numerator during multiplication
  @Test
  public void numeratorOverflow() {
      Rational r1 = new Rational(Integer.MAX_VALUE, 1);
      Rational r2 = new Rational(2, 1);
      assertThrows(IllegalArgumentException.class, () -> r1.times(r2), "Should throw IllegalArgumentException due to numerator overflow");
  }

  // Test for overflow in the denominator during multiplication
  @Test
  public void denominatorOverflow() {
      Rational r1 = new Rational(1, Integer.MAX_VALUE);
      Rational r2 = new Rational(1, 2);
      assertThrows(IllegalArgumentException.class, () -> r1.times(r2), "Should throw IllegalArgumentException due to denominator overflow");
  }

  // Test multiplying by zero
  @Test
  public void multiplyByZero() {
      Rational r1 = new Rational(2, 3);
      Rational zero = new Rational(0, 1);
      Rational result = r1.times(zero);
      assertEquals(0, result.getNumerator(), "Numerator should be zero");
      assertTrue(result.getDenominator() != 0, "Denominator should not be zero");
  }

  // Test for large numbers that don't cause overflow
  @Test
  public void multiplyLargeNumbersWithoutOverflow() {
      Rational r1 = new Rational(Integer.MAX_VALUE / 2, 1);
      Rational r2 = new Rational(1, 2);
      Rational result = r1.times(r2);
      assertEquals(Integer.MAX_VALUE / 2, result.getNumerator(), "Numerator should equal Integer.MAX_VALUE / 2 without overflow");
      assertEquals(2, result.getDenominator(), "Denominator should be correctly calculated");
  }

  // Test ensuring that the product is simplified if possible
  @Test
  public void multiplyAndSimplify() {
      Rational r1 = new Rational(2, 4);
      Rational r2 = new Rational(4, 2);
      Rational result = r1.times(r2);
      assertEquals(1, result.getNumerator(), "Numerator should be simplified to 1");
      assertEquals(1, result.getDenominator(), "Denominator should be simplified to 1");
  }
  
  // TESTS FOR :: plus
  // Test adding two positive rational numbers
  @Test
  public void addTwoPositiveRationals() {
      Rational r1 = new Rational(1, 4);
      Rational r2 = new Rational(3, 4);
      Rational result = r1.plus(r2);
      assertEquals(1, result.getNumerator(), "Numerator should be 1 after addition");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 after addition");
  }

  // Test adding a positive and a negative rational number
  @Test
  public void addPositiveAndNegativeRational() {
      Rational r1 = new Rational(1, 2);
      Rational r2 = new Rational(-1, 4);
      Rational result = r1.plus(r2);
      assertEquals(1, result.getNumerator(), "Numerator should be 1 after addition");
      assertEquals(4, result.getDenominator(), "Denominator should be 4 after addition");
  }

  // Test adding two negative rational numbers
  @Test
  public void addTwoNegativeRationals() {
      Rational r1 = new Rational(-1, 3);
      Rational r2 = new Rational(-2, 3);
      Rational result = r1.plus(r2);
      assertEquals(-1, result.getNumerator(), "Numerator should be -1 after addition");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 after addition");
  }

  // Test for potential overflow in addition
  @Test
  public void additionOverflow() {
      Rational r1 = new Rational(Integer.MAX_VALUE, 1);
      Rational r2 = new Rational(1, 1);
      assertThrows(IllegalArgumentException.class, () -> r1.plus(r2), "Should throw IllegalArgumentException due to potential overflow");
  }

  // Test adding zero to a rational number
  @Test
  public void addZeroToRational() {
      Rational r1 = new Rational(2, 3);
      Rational zero = new Rational(0, 1);
      Rational result = r1.plus(zero);
      assertEquals(2, result.getNumerator(), "Numerator should remain unchanged after adding zero");
      assertEquals(3, result.getDenominator(), "Denominator should remain unchanged after adding zero");
  }

  // Test adding rationals that require simplification
  @Test
  public void addRationalsRequiringSimplification() {
      Rational r1 = new Rational(1, 6);
      Rational r2 = new Rational(1, 3);
      Rational result = r1.plus(r2);
      assertEquals(1, result.getNumerator(), "Numerator should be 1 after simplification");
      assertEquals(2, result.getDenominator(), "Denominator should be 2 after simplification");
  }

  // Test adding two rational numbers resulting in a negative rational number
  @Test
  public void addRationalsResultingInNegative() {
      Rational r1 = new Rational(1, 4);
      Rational r2 = new Rational(-3, 4);
      Rational result = r1.plus(r2);
      assertEquals(-1, result.getNumerator(), "Numerator should be -1 after addition");
      assertEquals(2, result.getDenominator(), "Denominator should be 2 after addition");
  }

  // Test adding two large rational numbers that would not cause overflow
  @Test
  public void addLargeRationalsWithoutOverflow() {
      Rational r1 = new Rational(Integer.MAX_VALUE - 1, 2);
      Rational r2 = new Rational(1, 2);
      Rational result = r1.plus(r2);
      assertEquals(Integer.MAX_VALUE, result.getNumerator(), "Numerator should match Integer.MAX_VALUE without causing overflow");
      assertEquals(2, result.getDenominator(), "Denominator should be 2");
  }

  // Test addition resulting in zero
  @Test
  public void addInverseRationalsResultingInZero() {
      Rational r1 = new Rational(1, 2);
      Rational r2 = r1.opposite();
      Rational result = r1.plus(r2);
      assertEquals(0, result.getNumerator(), "Numerator should be 0 after adding inverses");
      assertEquals(1, result.getDenominator(), "Denominator should be normalized to 1 after adding inverses");
  }
  
  // TESTS FOR :: minus
  // Test subtracting a smaller rational number from a larger one
  @Test
  public void subtractSmallerFromLargerRational() {
      Rational r1 = new Rational(3, 4);
      Rational r2 = new Rational(1, 4);
      Rational result = r1.minus(r2);
      assertEquals(1, result.getNumerator(), "Numerator should be 1 after subtraction");
      assertEquals(2, result.getDenominator(), "Denominator should be 2 after subtraction");
  }

  // Test subtracting a larger rational number from a smaller one, resulting in a negative number
  @Test
  public void subtractLargerFromSmallerRational() {
      Rational r1 = new Rational(1, 4);
      Rational r2 = new Rational(3, 4);
      Rational result = r1.minus(r2);
      assertEquals(-1, result.getNumerator(), "Numerator should be -1 after subtraction");
      assertEquals(2, result.getDenominator(), "Denominator should be 2 after subtraction");
  }

  // Test subtracting two equal rational numbers, resulting in zero
  @Test
  public void subtractEqualRationals() {
      Rational r1 = new Rational(3, 4);
      Rational r2 = new Rational(3, 4);
      Rational result = r1.minus(r2);
      assertEquals(0, result.getNumerator(), "Numerator should be 0 after subtracting equal rationals");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 after subtraction");
  }

  // Test subtracting zero from a rational number
  @Test
  public void subtractZeroFromRational() {
      Rational r1 = new Rational(2, 3);
      Rational zero = new Rational(0, 1);
      Rational result = r1.minus(zero);
      assertEquals(2, result.getNumerator(), "Numerator should remain unchanged after subtracting zero");
      assertEquals(3, result.getDenominator(), "Denominator should remain unchanged after subtracting zero");
  }

  // Test subtracting a rational number from zero
  @Test
  public void subtractRationalFromZero() {
      Rational zero = new Rational(0, 1);
      Rational r1 = new Rational(2, 3);
      Rational result = zero.minus(r1);
      assertEquals(-2, result.getNumerator(), "Numerator should be -2 after subtraction");
      assertEquals(3, result.getDenominator(), "Denominator should be 3 after subtraction");
  }

  // Test subtraction that requires simplification
  @Test
  public void subtractRationalsRequiringSimplification() {
      Rational r1 = new Rational(1, 2);
      Rational r2 = new Rational(1, 4);
      Rational result = r1.minus(r2);
      assertEquals(1, result.getNumerator(), "Numerator should be 1 after simplification");
      assertEquals(4, result.getDenominator(), "Denominator should be 4 after simplification");
  }

  // Test subtracting two negative rational numbers
  @Test
  public void subtractTwoNegativeRationals() {
      Rational r1 = new Rational(-1, 4);
      Rational r2 = new Rational(-1, 2);
      Rational result = r1.minus(r2);
      assertEquals(1, result.getNumerator(), "Numerator should be 1 after subtraction");
      assertEquals(4, result.getDenominator(), "Denominator should be 4 after subtraction");
  }

  // Test subtracting rational numbers that result in a large denominator
//  @Test
//  public void subtractRationalsResultingInLargeDenominator() {
//      Rational r1 = new Rational(1, 1000000);
//      Rational r2 = new Rational(1, 1000001);
//      Rational result = r1.minus(r2);
//      // Expected values are calculated considering the large denominators involved
//      assertTrue(result.getNumerator() < 0, "Numerator should be negative after subtraction");
//      assertTrue(result.getDenominator() > 1000000, "Denominator should be large after subtraction");
//  }
  
  // TESTS FOR :: dividesBy
  // Test dividing two positive rationals
  @Test
  public void divideTwoPositiveRationals() {
      Rational r1 = new Rational(1, 2);
      Rational r2 = new Rational(1, 4);
      Rational result = r1.dividesBy(r2);
      assertEquals(2, result.getNumerator(), "Numerator should be 2 after division");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 after division");
  }

  // Test dividing by a rational number that is zero
  @Test
  public void divideByZeroRational() {
      Rational r1 = new Rational(1, 2);
      Rational zero = new Rational(0, 1);
      assertThrows(IllegalArgumentException.class, () -> r1.dividesBy(zero), "Division by zero should throw IllegalArgumentException");
  }

  // Test dividing a zero rational by another rational
  @Test
  public void zeroDividedByRational() {
      Rational zero = new Rational(0, 1);
      Rational r1 = new Rational(1, 2);
      Rational result = zero.dividesBy(r1);
      assertEquals(0, result.getNumerator(), "Numerator should be 0 after division");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 after division");
  }

  // Test division resulting in a negative rational
  @Test
  public void divideResultingInNegativeRational() {
      Rational r1 = new Rational(-1, 2);
      Rational r2 = new Rational(1, 4);
      Rational result = r1.dividesBy(r2);
      assertEquals(-2, result.getNumerator(), "Numerator should be -2 after division");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 after division");
  }

  // Test division of two negative rationals resulting in a positive rational
  @Test
  public void divideTwoNegativeRationals() {
      Rational r1 = new Rational(-1, 2);
      Rational r2 = new Rational(-1, 4);
      Rational result = r1.dividesBy(r2);
      assertEquals(2, result.getNumerator(), "Numerator should be 2 after division");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 after division");
  }

  // Test potential overflow in numerator multiplication
//  @Test
//  public void numeratorMultiplicationOverflow() {
//      Rational r1 = new Rational(Integer.MAX_VALUE, 1);
//      Rational r2 = new Rational(1, Integer.MAX_VALUE);
//      assertDoesNotThrow(() -> r1.dividesBy(r2), "Should not throw due to overflow as multiplication by reciprocal avoids it");
//  }

  // Test potential overflow in denominator multiplication
//  @Test
//  public void denominatorMultiplicationOverflow() {
//      Rational r1 = new Rational(1, Integer.MAX_VALUE);
//      Rational r2 = new Rational(Integer.MAX_VALUE, 1);
//      assertDoesNotThrow(() -> r1.dividesBy(r2), "Should not throw due to overflow as multiplication by reciprocal avoids it");
//  }

  // Test division that simplifies to 1
  @Test
  public void divisionThatSimplifiesToOne() {
      Rational r1 = new Rational(2, 3);
      Rational r2 = new Rational(2, 3);
      Rational result = r1.dividesBy(r2);
      assertEquals(1, result.getNumerator(), "Numerator should be 1 after simplification");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 after simplification");
  }

  // Test division by reciprocal
  @Test
  public void divisionByReciprocal() {
      Rational r1 = new Rational(3, 4);
      Rational r2 = new Rational(4, 3);
      Rational result = r1.dividesBy(r2);
      assertEquals(9, result.getNumerator(), "Numerator should be 9 after division by reciprocal");
      assertEquals(16, result.getDenominator(), "Denominator should be 16 after division by reciprocal");
  }

  // Test division with large values to ensure no overflow
//  @Test
//  public void divisionWithLargeValuesNoOverflow() {
//      Rational r1 = new Rational(Integer.MAX_VALUE, 2);
//      Rational r2 = new Rational(1, Integer.MAX_VALUE);
//      Rational result = r1.dividesBy(r2);
//      assertTrue(result.getNumerator() > 0, "Numerator should be positive after division");
//      assertTrue(result.getDenominator() > 0, "Denominator should be positive after division");
//  }
  
  // TESTS FOR :: raisedToThePowerOf
  // Test raising a rational number to a positive power
  @Test
  public void raiseToPositivePower() {
      Rational r = new Rational(2, 3);
      Rational result = r.raisedToThePowerOf(2);
      assertEquals(4, result.getNumerator(), "Numerator should be 4 when raised to the power of 2");
      assertEquals(9, result.getDenominator(), "Denominator should be 9 when raised to the power of 2");
  }

  // Test raising a rational number to zero
  @Test
  public void raiseToZeroPower() {
      Rational r = new Rational(2, 3);
      Rational result = r.raisedToThePowerOf(0);
      assertEquals(1, result.getNumerator(), "Numerator should be 1 when raised to the power of 0");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 when raised to the power of 0");
  }

  // Test raising a rational number to a negative power
  @Test
  public void raiseToNegativePower() {
      Rational r = new Rational(2, 3);
      Rational result = r.raisedToThePowerOf(-1);
      assertEquals(3, result.getNumerator(), "Numerator should be 3 when raised to the power of -1 (reciprocal)");
      assertEquals(2, result.getDenominator(), "Denominator should be 2 when raised to the power of -1 (reciprocal)");
  }

  // Test raising zero to a positive power
  @Test
  public void zeroRaisedToPositivePower() {
      Rational r = new Rational(0, 1);
      Rational result = r.raisedToThePowerOf(2);
      assertEquals(0, result.getNumerator(), "Numerator should be 0 when 0 raised to any positive power");
      assertEquals(1, result.getDenominator(), "Denominator should be 1 when 0 raised to any positive power");
  }

  // Test attempting to raise zero to a negative power
  @Test
  public void zeroRaisedToNegativePower() {
      Rational r = new Rational(0, 1);
      assertThrows(IllegalArgumentException.class, () -> r.raisedToThePowerOf(-1), "Raising 0 to a negative power should throw IllegalArgumentException");
  }

  // Test raising a rational number to a large positive power to check for overflow
//  @Test
//  public void raiseToLargePositivePower() {
//      Rational r = new Rational(2, 3);
//      assertThrows(ArithmeticException.class, () -> r.raisedToThePowerOf(30), "Raising to a large power should throw ArithmeticException due to overflow");
//  }

  // Test raising a rational number to a large negative power to check for overflow
//  @Test
//  public void raiseToLargeNegativePower() {
//      Rational r = new Rational(2, 3);
//      assertThrows(ArithmeticException.class, () -> r.raisedToThePowerOf(-30), "Raising to a large negative power should throw ArithmeticException due to overflow");
//  }

  // Test edge case: Raising a negative rational number to an even power
  @Test
  public void negativeRationalToEvenPower() {
      Rational r = new Rational(-2, 3);
      Rational result = r.raisedToThePowerOf(2);
      assertEquals(4, result.getNumerator(), "Numerator should be positive when a negative rational is raised to an even power");
      assertEquals(9, result.getDenominator(), "Denominator should remain positive");
  }

  // Test edge case: Raising a negative rational number to an odd power
  @Test
  public void negativeRationalToOddPower() {
      Rational r = new Rational(-2, 3);
      Rational result = r.raisedToThePowerOf(3);
      assertEquals(-8, result.getNumerator(), "Numerator should be negative when a negative rational is raised to an odd power");
      assertEquals(27, result.getDenominator(), "Denominator should remain positive");
  }
  
  // TESTS FOR :: equals
  // Test equals with identical Rational objects
  @Test
  public void equalsIdenticalRational() {
      Rational r1 = new Rational(2, 3);
      Rational r2 = new Rational(2, 3);
      assertTrue(r1.equals(r2), "Identical Rational objects should be equal");
  }

  // Test equals with different Rational objects
  @Test
  public void equalsDifferentRational() {
      Rational r1 = new Rational(2, 3);
      Rational r2 = new Rational(3, 4);
      assertFalse(r1.equals(r2), "Different Rational objects should not be equal");
  }

  // Test equals with a Rational object and a Float
  @Test
  public void equalsWithFloat() {
      Rational r = new Rational(1, 2);
      Float f = 0.5f;
      assertTrue(r.equals(f), "Rational object and equivalent Float should be considered equal");
  }

  // Test equals with a Rational object and a slightly different Float
//  @Test
//  public void equalsWithSlightlyDifferentFloat() {
//      Rational r = new Rational(1, 2);
//      Float f = 0.5000001f;
//      assertFalse(r.equals(f), "Rational object and slightly different Float should not be considered equal");
//  }

  // Test equals with a Rational object and a Double
  @Test
  public void equalsWithDouble() {
      Rational r = new Rational(1, 2);
      Double d = 0.5;
      assertTrue(r.equals(d), "Rational object and equivalent Double should be considered equal");
  }

  // Test equals with a Rational object and a slightly different Double
//  @Test
//  public void equalsWithSlightlyDifferentDouble() {
//      Rational r = new Rational(1, 2);
//      Double d = 0.5000000000001;
//      assertFalse(r.equals(d), "Rational object and slightly different Double should not be considered equal");
//  }

  // Test equals with a Rational object and an unrelated type
  @Test
  public void equalsWithUnrelatedType() {
      Rational r = new Rational(1, 2);
      String s = "1/2";
      assertFalse(r.equals(s), "Rational object and unrelated type should not be considered equal");
  }

  // Test equals with a Rational object and null
  @Test
  public void equalsWithNull() {
      Rational r = new Rational(1, 2);
      assertFalse(r.equals(null), "Rational object and null should not be considered equal");
  }

  // Test equals with a Rational object against itself
  @Test
  public void equalsWithItself() {
      Rational r = new Rational(1, 2);
      assertTrue(r.equals(r), "Rational object compared with itself should be considered equal");
  }
  
  // TESTS FOR :: greaterThan(number)
  // Test greaterThan with a smaller Rational number
  @Test
  public void greaterThanSmallerNumber() {
      Rational r1 = new Rational(3, 2);
      Rational r2 = new Rational(1, 2);
      assertTrue(r1.greaterThan(r2), "3/2 should be greater than 1/2");
  }

  // Test greaterThan with a larger Rational number
  @Test
  public void greaterThanLargerNumber() {
      Rational r1 = new Rational(1, 3);
      Rational r2 = new Rational(2, 3);
      assertFalse(r1.greaterThan(r2), "1/3 should not be greater than 2/3");
  }

  // Test greaterThan with an equal Rational number
  @Test
  public void greaterThanEqualNumber() {
      Rational r1 = new Rational(2, 3);
      Rational r2 = new Rational(2, 3);
      assertFalse(r1.greaterThan(r2), "Equal Rational numbers should not be considered greater");
  }

  // Test greaterThan with a smaller Integer
  @Test
  public void greaterThanSmallerInteger() {
      Rational r = new Rational(5, 1);
      Integer n = 4;
      assertTrue(r.greaterThan(n), "5 should be greater than 4");
  }

  // Test greaterThan with a larger Integer
  @Test
  public void greaterThanLargerInteger() {
      Rational r = new Rational(2, 3);
      Integer n = 1;
      assertFalse(r.greaterThan(n), "2/3 should not be greater than 1");
  }

  // Test greaterThan with a Float
  @Test
  public void greaterThanFloat() {
      Rational r = new Rational(10, 3);
      Float f = 3.3f;
      assertTrue(r.greaterThan(f), "10/3 should be greater than 3.3");
  }

  // Test greaterThan with a Double that is very close
//  @Test
//  public void greaterThanCloseDouble() {
//      Rational r = new Rational(1000, 333);
//      Double d = 3.003;
//      assertFalse(r.greaterThan(d), "1000/333 should not be considered greater than a close double value of 3.003");
//  }

  // Test greaterThan with boundary values
  @Test
  public void greaterThanIntBoundaryValues() {
      Rational r = new Rational(Integer.MAX_VALUE, 1);
      Integer n = Integer.MAX_VALUE - 1;
      assertTrue(r.greaterThan(n), "Integer.MAX_VALUE should be considered greater than Integer.MAX_VALUE - 1");
  }

  // Test greaterThan with negative numbers
  @Test
  public void greaterThanIntNegativeNumbers() {
      Rational r1 = new Rational(-1, 2);
      Rational r2 = new Rational(-2, 3);
      assertTrue(r1.greaterThan(r2), "-1/2 should be considered greater than -2/3");
  }
  
  // TESTS FOR :: greaterThan(Rational)
  // Test greaterThan with a smaller Rational number
  @Test
  public void greaterThanSmallerRational() {
      Rational r1 = new Rational(3, 2);
      Rational r2 = new Rational(1, 2);
      assertTrue(r1.greaterThan(r2), "3/2 should be greater than 1/2");
  }

  // Test greaterThan with a larger Rational number
  @Test
  public void greaterThanLargerRational() {
      Rational r1 = new Rational(1, 3);
      Rational r2 = new Rational(2, 3);
      assertFalse(r1.greaterThan(r2), "1/3 should not be greater than 2/3");
  }

  // Test greaterThan with an equal Rational number
  @Test
  public void greaterThanEqualRational() {
      Rational r1 = new Rational(2, 3);
      Rational r2 = new Rational(2, 3);
      assertFalse(r1.greaterThan(r2), "Equal Rational numbers should not be considered greater");
  }

  // Test greaterThan with negative numbers
  @Test
  public void greaterThanNegativeNumbers() {
      Rational r1 = new Rational(-1, 2);
      Rational r2 = new Rational(-2, 3);
      assertTrue(r1.greaterThan(r2), "-1/2 should be considered greater than -2/3");
  }

  // Test greaterThan with boundary values
  @Test
  public void greaterThanBoundaryValues() {
      Rational r1 = new Rational(Integer.MAX_VALUE, 1);
      Rational r2 = new Rational(Integer.MAX_VALUE - 1, 1);
      assertTrue(r1.greaterThan(r2), "Integer.MAX_VALUE should be considered greater than Integer.MAX_VALUE - 1");
  }

  // TESTS FOR :: lessThan
  // Test lessThan with a smaller Rational number
  @Test
  public void lessThanWithSmallerRational() {
      Rational smaller = new Rational(1, 2);
      Rational larger = new Rational(3, 2);
      assertTrue(smaller.lessThan(larger), "1/2 should be less than 3/2");
  }

  // Test lessThan with a larger Rational number
  @Test
  public void lessThanWithLargerRational() {
      Rational smaller = new Rational(1, 2);
      Rational larger = new Rational(3, 2);
      assertFalse(larger.lessThan(smaller), "3/2 should not be less than 1/2");
  }

  // Test lessThan with equal Rational numbers
  @Test
  public void lessThanWithEqualRational() {
      Rational r1 = new Rational(2, 3);
      Rational r2 = new Rational(2, 3);
      assertFalse(r1.lessThan(r2), "2/3 should not be less than 2/3");
  }

  // Test lessThan with negative numbers
  @Test
  public void lessThanWithNegativeNumbers() {
      Rational negativeSmall = new Rational(-1, 2);
      Rational negativeLarge = new Rational(-3, 2);
      assertTrue(negativeLarge.lessThan(negativeSmall), "-3/2 should be less than -1/2");
  }

  // Test lessThan with zero
  @Test
  public void lessThanWithZero() {
      Rational zero = new Rational(0, 1);
      Rational positive = new Rational(1, 2);
      assertTrue(zero.lessThan(positive), "0 should be less than 1/2");
  }

  // Test lessThan with one Rational having a larger denominator
  @Test
  public void lessThanWithLargerDenominator() {
      Rational smallerNumerator = new Rational(1, 4);
      Rational largerNumeratorSameDenominator = new Rational(3, 4);
      assertTrue(smallerNumerator.lessThan(largerNumeratorSameDenominator), "1/4 should be less than 3/4");
  }

  // Test lessThan with different denominators
  @Test
  public void lessThanWithDifferentDenominators() {
      Rational smaller = new Rational(1, 2);
      Rational largerDifferentDenominator = new Rational(2, 3);
      assertTrue(smaller.lessThan(largerDifferentDenominator), "1/2 should be less than 2/3");
  }

  // Test boundary conditions with maximum integer values
  @Test
  public void lessThanBoundaryConditionMaxInt() {
      Rational nearMax = new Rational(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
      Rational maxRational = new Rational(Integer.MAX_VALUE, Integer.MAX_VALUE);
      assertTrue(nearMax.lessThan(maxRational), "Near max integer value should be less than max integer value as Rational");
  }

  // Test handling of Rational numbers that could potentially overflow
  @Test
  public void lessThanWithPotentialOverflow() {
      Rational largeNumerator1 = new Rational(Integer.MAX_VALUE, 2);
      Rational largeNumerator2 = new Rational(Integer.MAX_VALUE - 1, 2);
      assertFalse(largeNumerator1.lessThan(largeNumerator2), "A larger numerator with same denominator should not be less");
  }
  
  // TESTS FOR :: isZero
  // Test isZero when the rational number is indeed zero
  @Test
  public void isZeroWithZeroNumerator() {
      Rational zeroRational = new Rational(0, 5);
      assertTrue(zeroRational.isZero(), "A rational number with a numerator of 0 should be considered zero.");
  }

  // Test isZero with a positive rational number
  @Test
  public void isZeroWithPositiveRational() {
      Rational positiveRational = new Rational(1, 5);
      assertFalse(positiveRational.isZero(), "A positive rational number should not be considered zero.");
  }

  // Test isZero with a negative rational number
  @Test
  public void isZeroWithNegativeRational() {
      Rational negativeRational = new Rational(-1, 5);
      assertFalse(negativeRational.isZero(), "A negative rational number should not be considered zero.");
  }

  // Test isZero with a large numerator
  @Test
  public void isZeroWithLargeNumerator() {
      Rational largeRational = new Rational(Integer.MAX_VALUE, 1);
      assertFalse(largeRational.isZero(), "A rational number with a large positive numerator should not be considered zero.");
  }

  // Test isZero with a large negative numerator
//  @Test
//  public void isZeroWithLargeNegativeNumerator() {
//      Rational largeNegativeRational = new Rational(Integer.MIN_VALUE, 1);
//      assertFalse(largeNegativeRational.isZero(), "A rational number with a large negative numerator should not be considered zero.");
//  }

  // Test isZero with a very small numerator
  @Test
  public void isZeroWithSmallNumerator() {
      Rational smallRational = new Rational(1, Integer.MAX_VALUE);
      assertFalse(smallRational.isZero(), "A rational number with a very small value should not be considered zero.");
  }

  // Test isZero with the numerator being the only part that makes it zero
  @Test
  public void isZeroWithZeroNumeratorAndLargeDenominator() {
      Rational zeroWithLargeDenominator = new Rational(0, Integer.MAX_VALUE);
      assertTrue(zeroWithLargeDenominator.isZero(), "A rational number with a zero numerator, regardless of the denominator, should be considered zero.");
  }

  // Test isZero in the edge case of MAX_VALUE denominator
  @Test
  public void isZeroWithMaxValueDenominator() {
      Rational edgeCaseRational = new Rational(0, Integer.MAX_VALUE);
      assertTrue(edgeCaseRational.isZero(), "Even with the largest possible denominator, if the numerator is 0, the rational number should be considered zero.");
  }

  // Ensure that the denominator does not affect the zero check
  @Test
  public void isZeroWithNonZeroNumeratorAndDenominator() {
      Rational nonZeroRational = new Rational(1, Integer.MAX_VALUE);
      assertFalse(nonZeroRational.isZero(), "A non-zero numerator should mean the rational number is not considered zero, regardless of the denominator.");
  }
  
  // TESTS FOR :: isOne
  // Test isOne when both numerator and denominator are equal and not zero
  @Test
  public void isOneWithEqualNumeratorAndDenominator() {
      Rational one = new Rational(5, 5);
      assertTrue(one.isOne(), "A rational number with equal numerator and denominator should be considered one.");
  }

  // Test isOne when numerator and denominator are equal but negative
  @Test
  public void isOneWithNegativeValues() {
      Rational negativeOne = new Rational(-5, -5);
      assertTrue(negativeOne.isOne(), "A rational number with equal negative numerator and denominator should also be considered one.");
  }

  // Test isOne when the numerator and denominator are not equal
  @Test
  public void isOneWithUnequalNumeratorAndDenominator() {
      Rational notOne = new Rational(2, 3);
      assertFalse(notOne.isOne(), "A rational number with unequal numerator and denominator should not be considered one.");
  }

  // Test isOne with zero numerator
  @Test
  public void isOneWithZeroNumerator() {
      Rational zero = new Rational(0, 5);
      assertFalse(zero.isOne(), "A rational number with a zero numerator should not be considered one.");
  }

  // Test isOne with zero denominator (though should never be possible in a well-defined Rational class)
  // This test case assumes the Rational class prevents a zero denominator but includes it for completeness.
//  @Test
//  public void isOneWithZeroDenominator() {
//      Exception exception = assertThrows(IllegalArgumentException.class, () -> {
//          new Rational(5, 0);
//      }, "A rational number with a zero denominator should not be allowed.");
//      assertTrue(exception.getMessage().contains("denominator cannot be zero"));
//  }

  // Test isOne for large equal numerator and denominator
  @Test
  public void isOneWithLargeEqualValues() {
      Rational largeOne = new Rational(Integer.MAX_VALUE, Integer.MAX_VALUE);
      assertTrue(largeOne.isOne(), "A rational number with large equal numerator and denominator should be considered one.");
  }

  // Test isOne for a large numerator and a smaller but non-zero denominator
  @Test
  public void isOneWithLargeNumeratorAndSmallerDenominator() {
      Rational notOneLarge = new Rational(Integer.MAX_VALUE, 1);
      assertFalse(notOneLarge.isOne(), "A rational number with a large numerator and smaller denominator should not be considered one.");
  }

  // Test isOne with one as the numerator and a large denominator
  @Test
  public void isOneWithOneNumeratorAndLargeDenominator() {
      Rational notOneSmall = new Rational(1, Integer.MAX_VALUE);
      assertFalse(notOneSmall.isOne(), "A rational number with one as numerator and a large denominator should not be considered one.");
  }

  // Test isOne for one represented with negative numbers
  @Test
  public void isOneWithNegativeOneRepresentation() {
      Rational negativeRepresentationOfOne = new Rational(-1, -1);
      assertTrue(negativeRepresentationOfOne.isOne(), "A rational number represented with -1/-1 should be considered one.");
  }
  
  // TESTS FOR :: isMinusOne
  // Test isMinusOne for a simple case where the rational number is -1
  @Test
  public void isMinusOneSimpleCase() {
      Rational minusOne = new Rational(-1, 1);
      assertTrue(minusOne.isMinusOne(), "Rational number -1/1 should be recognized as -1.");
  }

  // Test isMinusOne where numerator is positive and denominator is negative, representing -1
  @Test
  public void isMinusOneWithPositiveNumeratorAndNegativeDenominator() {
      Rational minusOne = new Rational(1, -1);
      assertTrue(minusOne.isMinusOne(), "Rational number 1/-1 should be recognized as -1.");
  }

  // Test isMinusOne for a rational number that is not -1 (positive case)
  @Test
  public void isNotMinusOnePositive() {
      Rational notMinusOne = new Rational(1, 1);
      assertFalse(notMinusOne.isMinusOne(), "Rational number 1/1 should not be recognized as -1.");
  }

  // Test isMinusOne for a rational number that is not -1 (greater magnitude case)
  @Test
  public void isNotMinusOneDifferentMagnitudes() {
      Rational notMinusOne = new Rational(-2, 1);
      assertFalse(notMinusOne.isMinusOne(), "Rational number -2/1 should not be recognized as -1.");
  }

  // Test isMinusOne with zero numerator
  @Test
  public void isMinusOneWithZeroNumerator() {
      Rational zero = new Rational(0, -1);
      assertFalse(zero.isMinusOne(), "Rational number 0/-1 should not be recognized as -1.");
  }

  // Test isMinusOne for large equivalent values representing -1
//  @Test
//  public void isMinusOneWithLargeValues() {
//      Rational largeMinusOne = new Rational(Integer.MIN_VALUE, Integer.MAX_VALUE);
//      assertTrue(largeMinusOne.isMinusOne(), "Rational number with large equivalent negative values should be recognized as -1.");
//  }

  // Test isMinusOne for a case that would represent -1 if not for simplification
//  @Test
//  public void isMinusOneAfterSimplification() {
//      Rational simplifiableMinusOne = new Rational(-2, 2);
//      assertFalse(simplifiableMinusOne.isMinusOne(), "Rational number -2/2, simplifiable to -1, should not directly be recognized as -1 without simplification.");
//  }

  // Test isMinusOne for edge cases near Integer boundaries
  @Test
  public void isMinusOneNearIntegerBoundaries() {
      Rational edgeCaseMinusOne = new Rational(Integer.MAX_VALUE, -Integer.MAX_VALUE);
      assertTrue(edgeCaseMinusOne.isMinusOne(), "Rational number near integer boundaries representing -1 should be recognized as -1.");
  }

  // Test isMinusOne with extremely large numbers to ensure proper handling and no overflow
  @Test
  public void isMinusOneWithExtremelyLargeNumbers() {
      Rational largeNegative = new Rational(-Integer.MAX_VALUE, Integer.MAX_VALUE);
      assertTrue(largeNegative.isMinusOne(), "Extremely large negative rational numbers that represent -1 should be recognized as -1.");
  }

  // Test isMinusOne when both numerator and denominator are zero
  // This test assumes the Rational class prevents a zero denominator but includes it for completeness.
//  @Test
//  public void isMinusOneWithZeroDenominator() {
//      Exception exception = assertThrows(IllegalArgumentException.class, () -> {
//          new Rational(0, 0);
//      }, "A rational number with a zero denominator should not be allowed.");
//      assertTrue(exception.getMessage().contains("denominator cannot be zero"));
//  }
  
  // TESTS FOR :: toString
  // Test toString for a positive rational number
  @Test
  public void toStringPositiveRational() {
      Rational rational = new Rational(3, 4);
      assertEquals("3/4", rational.toString(), "Positive rational should be in 'numerator/denominator' format.");
  }

  // Test toString for a negative rational number (negative numerator)
  @Test
  public void toStringNegativeNumerator() {
      Rational rational = new Rational(-3, 4);
      assertEquals("-3/4", rational.toString(), "Negative numerator should be represented with a leading '-' sign.");
  }

  // Test toString for a negative rational number (negative denominator)
  @Test
  public void toStringNegativeDenominator() {
      Rational rational = new Rational(3, -4);
      assertEquals("-3/4", rational.toString(), "Negative denominator should move the '-' sign to the numerator.");
  }

  // Test toString for a whole number representation
  @Test
  public void toStringWholeNumber() {
      Rational rational = new Rational(5, 1);
      assertEquals("5", rational.toString(), "Rational with denominator of 1 should be represented as a whole number.");
  }

  // Test toString for zero
  @Test
  public void toStringZero() {
      Rational rational = new Rational(0, 5);
      assertEquals("0", rational.toString(), "Zero should be represented as '0', regardless of the denominator.");
  }

  // Test toString for a rational number that simplifies to a whole number
  @Test
  public void toStringSimplifiedWholeNumber() {
      Rational rational = new Rational(10, 2);
      assertEquals("5", rational.toString(), "Rational simplifying to a whole number should be represented as such.");
  }

  // Test toString for a large rational number
  @Test
  public void toStringLargeRational() {
      Rational rational = new Rational(Integer.MAX_VALUE, 2);
      assertEquals(Integer.MAX_VALUE + "/2", rational.toString(), "Large rational numbers should be represented accurately.");
  }

  // Test toString for a rational number that simplifies to -1
  @Test
  public void toStringSimplifiedMinusOne() {
      Rational rational = new Rational(-5, 5);
      assertEquals("-1", rational.toString(), "Rational simplifying to -1 should be represented as '-1'.");
  }

  // Test toString for edge cases around zero
  @Test
  public void toStringEdgeCasesAroundZero() {
      Rational positiveSmall = new Rational(1, Integer.MAX_VALUE);
      Rational negativeSmall = new Rational(-1, Integer.MAX_VALUE);
      assertEquals("1/" + Integer.MAX_VALUE, positiveSmall.toString(), "Very small positive rational numbers should be accurately represented.");
      assertEquals("-1/" + Integer.MAX_VALUE, negativeSmall.toString(), "Very small negative rational numbers should maintain correct sign representation.");
  }
  
//  @Test
//  public void toStringWithMinValueNumerator() {
//      Rational rational = new Rational(Integer.MIN_VALUE, 1);
//      assertEquals(Integer.MIN_VALUE + "/1", rational.toString(), "Rational with Integer.MIN_VALUE as numerator should be accurately represented.");
//  }

//  // Test toString with Integer.MIN_VALUE as denominator
//  @Test
//  public void toStringWithMinValueDenominator() {
//      Rational rational = new Rational(1, Integer.MIN_VALUE);
//      assertEquals("-1/" + (-Integer.MIN_VALUE), rational.toString(), "Rational with Integer.MIN_VALUE as denominator should correctly move the negative sign to the numerator.");
//  }

  // Test toString with Integer.MAX_VALUE as denominator
  @Test
  public void toStringWithMaxValueDenominator() {
      Rational rational = new Rational(1, Integer.MAX_VALUE);
      assertEquals("1/" + Integer.MAX_VALUE, rational.toString(), "Rational with Integer.MAX_VALUE as denominator should be accurately represented.");
  }

  // Test toString with both numerator and denominator as Integer.MAX_VALUE
  @Test
  public void toStringWithMaxValueNumeratorAndDenominator() {
      Rational rational = new Rational(Integer.MAX_VALUE, Integer.MAX_VALUE);
      assertEquals("1", rational.toString(), "Rational with both numerator and denominator as Integer.MAX_VALUE should simplify to 1.");
  }

  // Test toString with negative numerator slightly greater than negative denominator
  @Test
  public void toStringNegativeNumeratorGreaterThanNegativeDenominator() {
      Rational rational = new Rational(-Integer.MAX_VALUE, -Integer.MAX_VALUE + 1);
      // The expected value should reflect that the negative sign will be normalized to the numerator
      assertEquals("2147483647/2147483646", rational.toString(), "Negative numerator slightly greater than negative denominator should maintain correct sign representation.");
  }

  // Test toString with positive numerator slightly less than negative denominator
  @Test
  public void toStringPositiveNumeratorLessThanNegativeDenominator() {
      Rational rational = new Rational(Integer.MAX_VALUE - 1, -Integer.MAX_VALUE);
      assertEquals("-" + (Integer.MAX_VALUE - 1) + "/" + Integer.MAX_VALUE, rational.toString(), "Positive numerator slightly less than negative denominator should correctly move the negative sign to the numerator.");
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}
