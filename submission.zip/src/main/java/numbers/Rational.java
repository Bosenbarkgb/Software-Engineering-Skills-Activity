package numbers;

import java.math.BigInteger;

public class Rational extends Number implements Comparable<Number> {

  private static final long serialVersionUID = 1L;
  private int numerator;
  private int denominator;

  /**
   * Constructs a {@code Rational} number with numerator 0 and denominator 1.
   */
  public Rational() {
    this(0, 1); // chaining with 2 param constructor
  }

  /**
   * Constructs a {@code Rational} number with the specified numerator and 1 as the denominator.
   *
   * @param numerator The numerator of the rational number.
   */
  public Rational(int numerator) {
    this(numerator, 1); // chaining with 2 param constructor
  }

  /**
   * Constructs a {@code Rational} number with the specified numerator and denominator. Automatically
   * simplifies the fraction and ensures the denominator is positive.
   *
   * @param numerator   The numerator of the rational number.
   * @param denominator The denominator of the rational number. Cannot be zero.
   * @throws IllegalArgumentException if the denominator is zero.
   */
  public Rational(int a, int b) {
      if (b == 0) {
          throw new IllegalArgumentException("Denominator can't be zero.");
      }
      
      if (a == Integer.MIN_VALUE && b == Integer.MIN_VALUE) {
          this.numerator = 1;
          this.denominator = 1;
      }
      // Checking for potential overflow when negating the minimum integer value
      if (a == Integer.MIN_VALUE || b == Integer.MIN_VALUE) {
          throw new IllegalArgumentException("Operation would cause integer overflow.");
      }

      // Ensuring the negative sign is on the numerator and reducing the fraction
      if (b < 0) {
          a = -a;
          b = -b;
      }
      int gcd = gcd(Math.abs(a), b); // Compute the greatest common divisor
      numerator = a / gcd;
      denominator = b / gcd;
  }

  /**
   * Constructs a new {@code Rational} that is a copy of the specified {@code Rational}.
   *
   * @param original The {@code Rational} to copy.
   */
  public Rational(Rational original) {
    this.numerator = original.numerator;
    this.denominator = original.denominator;
  }

  /**
   * Returns the numerator of this rational number.
   *
   * @return The numerator.
   */
  public int getNumerator() {
    return numerator;
  }

  /**
   * Returns the denominator of this rational number.
   *
   * @return The denominator.
   */
  public int getDenominator() {
    return denominator;
  }

  /**
   * Calculates the greatest common divisor (GCD) of two integers. Uses the Euclidean algorithm.
   *
   * @param a The first integer.
   * @param b The second integer.
   * @return The GCD of {@code a} and {@code b}.
   */
  static int gcd(int a, int b) {
	    a = Math.abs(a);
	    b = Math.abs(b);
	    int result = b == 0 ? a : gcd(b, a % b);
	    return result; // result non-negative
	}

  /**
   * Returns the integer part of the rational number
   */
  @Override
  public int intValue() {
    return numerator / denominator;
  }

  /**
   * Returns the long part of the rational number
   */
  @Override
  public long longValue() {
    return (long) numerator / denominator;
  }

  /**
   * Returns the float representation of the rational number
   */
  @Override
  public float floatValue() {
    return (float) numerator / denominator;
  }

  /**
   * Returns the double representation of the rational number
   */
  @Override
  public double doubleValue() {
    return (double) numerator / denominator;
  }

  /**
   * Compares the rational numer with another number
   */
  @Override
  public int compareTo(Number o) {
    double thisVal = this.doubleValue();
    double otherVal = o.doubleValue();
    return Double.compare(thisVal, otherVal);
  }

  /**
   * Returns the additive inverse of this rational number.
   *
   * @return A {@code Rational} representing the additive inverse.
   * @throws IllegalArgumentException if the operation would cause integer overflow.
   */
  public Rational opposite() {
      if (this.numerator == Integer.MIN_VALUE) {
          throw new IllegalArgumentException("Negating the numerator causes integer overflow.");
      }
      return new Rational(-this.numerator, this.denominator);
  }


  /**
   * Returns the multiplicative inverse (reciprocal) of this rational number.
   *
   * @return A {@code Rational} representing the reciprocal.
   * @throws IllegalArgumentException if the numerator is zero.
   */
  public Rational reciprocal() {
	  if (this.numerator == 0) {
	    throw new IllegalArgumentException("Can't get the reciprocal of 0");
	  }
	  // Adjust signs to ensure the denominator is positive in the reciprocal
	  if (this.numerator < 0) {
	    return new Rational(-this.denominator, -this.numerator);
	  } else {
	    return new Rational(this.denominator, this.numerator);
	  }
	}


  /**
   * Multiplies this rational number by another rational number with overflow detection.
   *
   * @param r The rational number to multiply by.
   * @return The product of this rational number and {@code r}.
   * @throws IllegalArgumentException if the multiplication results in values outside the range of int.
   */
  public Rational times(Rational r) {
      // Check for overflow in multiplication of numerators
      long tempNumerator = (long) this.numerator * r.numerator;
      if (tempNumerator < Integer.MIN_VALUE || tempNumerator > Integer.MAX_VALUE) {
          throw new IllegalArgumentException("Numerator overflow");
      }

      // Check for overflow in multiplication of denominators
      long tempDenominator = (long) this.denominator * r.denominator;
      if (tempDenominator < Integer.MIN_VALUE || tempDenominator > Integer.MAX_VALUE) {
          throw new IllegalArgumentException("Denominator overflow");
      }

      return new Rational((int)tempNumerator, (int)tempDenominator);
  }
  
  /**
   * Adds another rational number to this rational number with overflow detection.
   *
   * @param r The rational number to add.
   * @return The sum of this rational number and {@code r}.
   * @throws IllegalArgumentException if the operation causes integer overflow.
   */
  public Rational plus(Rational r) {
      BigInteger aNumerator = BigInteger.valueOf(this.numerator);
      BigInteger aDenominator = BigInteger.valueOf(this.denominator);
      BigInteger bNumerator = BigInteger.valueOf(r.numerator);
      BigInteger bDenominator = BigInteger.valueOf(r.denominator);

      // Perform the addition operation using BigInteger to avoid overflow
      BigInteger newNumerator = aNumerator.multiply(bDenominator).add(bNumerator.multiply(aDenominator));
      BigInteger newDenominator = aDenominator.multiply(bDenominator);

      // Simplify the fraction before creating the Rational object to ensure we don't miss any potential simplifications
      BigInteger gcd = newNumerator.gcd(newDenominator);
      newNumerator = newNumerator.divide(gcd);
      newDenominator = newDenominator.divide(gcd);

      // Check for overflow when converting back to int
      if (newNumerator.compareTo(BigInteger.valueOf(Integer.MAX_VALUE)) > 0 ||
          newNumerator.compareTo(BigInteger.valueOf(Integer.MIN_VALUE)) < 0 ||
          newDenominator.compareTo(BigInteger.valueOf(Integer.MAX_VALUE)) > 0 ||
          newDenominator.compareTo(BigInteger.valueOf(Integer.MIN_VALUE)) < 0) {
          throw new IllegalArgumentException("Operation causes integer overflow");
      }

      return new Rational(newNumerator.intValue(), newDenominator.intValue());
  }

  /**
   * Subtracts another rational number from this rational number.
   *
   * @param r The rational number to subtract.
   * @return The difference between this rational number and {@code r}.
   */
  public Rational minus(Rational r) {
    BigInteger aNumerator = BigInteger.valueOf(this.numerator);
    BigInteger aDenominator = BigInteger.valueOf(this.denominator);
    BigInteger bNumerator = BigInteger.valueOf(r.numerator);
    BigInteger bDenominator = BigInteger.valueOf(r.denominator);

    // Perform the operations using BigInteger
    BigInteger newNumerator = aNumerator
      .multiply(bDenominator)
      .subtract(aDenominator.multiply(bNumerator));
    BigInteger newDenominator = aDenominator.multiply(bDenominator);

    // Check for overflow when converting back to int
    if (
      newNumerator.compareTo(BigInteger.valueOf(Integer.MAX_VALUE)) > 0 ||
      newNumerator.compareTo(BigInteger.valueOf(Integer.MIN_VALUE)) < 0 ||
      newDenominator.compareTo(BigInteger.valueOf(Integer.MAX_VALUE)) > 0 ||
      newDenominator.compareTo(BigInteger.valueOf(Integer.MIN_VALUE)) < 0
    ) {
      throw new IllegalArgumentException("Operation causes integer overflow");
    }

    // Calculate gcd of BigInteger values
    BigInteger gcd = newNumerator.gcd(newDenominator);
    newNumerator = newNumerator.divide(gcd);
    newDenominator = newDenominator.divide(gcd);

    // Convert BigInteger back to int
    return new Rational(newNumerator.intValue(), newDenominator.intValue());
  }

  /**
   * Divides this rational number by another rational number with overflow detection.
   *
   * @param r The rational number to divide by.
   * @return The quotient of this rational number divided by {@code r}.
   * @throws IllegalArgumentException if {@code r} is zero or if the operation results in overflow.
   */
  public Rational dividesBy(Rational r) {
      // Check for division by 0
      if (r.numerator == 0) {
          throw new IllegalArgumentException("Division by 0 is invalid");
      }

      // Check for overflow in multiplication of numerator and r's denominator
      long tempNumerator = (long) this.numerator * r.denominator;
      if (tempNumerator < Integer.MIN_VALUE || tempNumerator > Integer.MAX_VALUE) {
          throw new IllegalArgumentException("Numerator multiplication overflow");
      }

      // Check for overflow in multiplication of denominator and r's numerator
      long tempDenominator = (long) this.denominator * r.numerator;
      if (tempDenominator < Integer.MIN_VALUE || tempDenominator > Integer.MAX_VALUE) {
          throw new IllegalArgumentException("Denominator multiplication overflow");
      }

      // Proceed with division (actually multiplication by reciprocal) if no overflow
      return new Rational((int) tempNumerator, (int) tempDenominator);
  }

  /**
   * Raises this rational number to the power of {@code n}.
   *
   * @param n The exponent.
   * @return This rational number raised to the power of {@code n}.
   * @throws IllegalArgumentException if attempting to raise zero to a negative power.
   */
  public Rational raisedToThePowerOf(int n) {
    if (this.numerator == 0 && n < 0) {
      throw new IllegalArgumentException("Can't raise 0 to a negative power");
    }

    // Handling negative powers by using the reciprocal
    if (n < 0) {
      // Swap numerator and denominator for reciprocal
      int newNumerator = (int) Math.pow(this.denominator, -n); // Raising to -n makes it positive
      int newDenominator = (int) Math.pow(this.numerator, -n);
      return new Rational(newNumerator, newDenominator);
    } else {
      int newNumerator = (int) Math.pow(this.numerator, n);
      int newDenominator = (int) Math.pow(this.denominator, n);
      return new Rational(newNumerator, newDenominator);
    }
  }

  // Logic to check equality of object
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }

    if (o instanceof Rational) {
      Rational other = (Rational) o;
      return (
        this.numerator == other.numerator &&
        this.denominator == other.denominator
      );
    } else if (o instanceof Float) {
      float difference = Math.abs(this.floatValue() - (Float) o);
      return difference < Math.pow(2, -20);
    } else if (o instanceof Double) {
      double difference = Math.abs(this.doubleValue() - (Double) o);
      return difference < Math.pow(2, -40);
    }
    return false;
  }

  /**
   * Checks if this rational number is greater than another number.
   *
   * @param n The number to compare against.
   * @return {@code true} if this is greater than {@code n}; {@code false} otherwise.
   */
  public boolean greaterThan(Number n) {
    return this.doubleValue() > n.doubleValue();
  }

  /**
   * Compares this rational number with another rational number to determine if this number is strictly greater.
   *
   * This method performs the comparison by converting both rational numbers to a common denominator and then comparing
   * their numerators. This approach avoids the need for floating-point arithmetic and preserves the accuracy of the comparison.
   *
   * @param r The rational number to compare against.
   * @return {@code true} if this rational number is strictly greater than {@code r}; {@code false} otherwise.
   */
  public boolean greaterThan(Rational r) {
    int thisNumerator = this.numerator * r.denominator;
    int rNumerator = r.numerator * this.denominator;

    return thisNumerator > rNumerator;
  }

  /**
   * Checks if this rational number is less than another rational number.
   *
   * @param r The rational number to compare against.
   * @return {@code true} if this is less than {@code r}; {@code false} otherwise.
   */
  public boolean lessThan(Rational r) {
    // Convert both rationals to a common denominator and compare numerators
    int thisNumerator = this.numerator * r.denominator;
    int rNumerator = r.numerator * this.denominator;

    return thisNumerator < rNumerator;
  }

  /**
   * Checks if this rational number is zero.
   *
   * @return {@code true} if this rational number is zero; {@code false} otherwise.
   */
  public boolean isZero() {
    return this.numerator == 0; // If the numerator is 0, the whole rational number is 0.
  }

  /**
   * Checks if this rational number is one.
   *
   * @return {@code true} if this rational number is one; {@code false} otherwise.
   */
  public boolean isOne() {
    return this.numerator == this.denominator && this.numerator != 0;
  }

  /**
   * Checks if this rational number is minus one.
   *
   * @return {@code true} if this rational number is minus one; {@code false} otherwise.
   */
  public boolean isMinusOne() {
    return this.numerator == -this.denominator && this.numerator != 0;
  }

  // Logic for representation as String
  public String toString() {
    // Ensure the negative sign is always in the numerator for representation
    if (denominator < 0) {
      return (-numerator) + "/" + (-denominator); // Correct the sign placement
    } else if (denominator == 1) {
      return String.valueOf(numerator); // Whole number representation
    } else {
      return numerator + "/" + denominator; // Standard fraction representation
    }
  }
}
